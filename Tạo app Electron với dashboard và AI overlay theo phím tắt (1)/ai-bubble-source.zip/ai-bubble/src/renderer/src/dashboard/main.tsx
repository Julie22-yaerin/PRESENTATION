import { createRoot } from 'react-dom/client'
import '../styles/theme.css'
import '../styles/dashboard.css'
import { App } from './App'

const container = document.getElementById('root')
if (!container) throw new Error('Dashboard root missing')

createRoot(container).render(<App />)
