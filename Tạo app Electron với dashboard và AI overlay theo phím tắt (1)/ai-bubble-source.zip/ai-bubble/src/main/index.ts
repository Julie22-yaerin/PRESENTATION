import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import {
  app,
  type BrowserWindow,
  desktopCapturer,
  dialog,
  ipcMain,
  protocol,
  screen,
  session,
  shell,
  systemPreferences
} from 'electron'
import {
  API,
  ASSET_SCHEME,
  DASH_KEYCODE,
  OVERLAY_ASK_TEXT,
  OVERLAY_AUDIO,
  OVERLAY_DRAG,
  OVERLAY_INTERACTIVE,
  OVERLAY_LEVEL,
  OVERLAY_MIC,
  OVERLAY_READY,
  OVERLAY_RECORD_ERROR,
  OVERLAY_REQUEST,
  OVERLAY_STATE
} from '../shared/ipc'
import type { AudioPayload } from '../shared/ipc'
import type { AppSettings, HealthReport, MicReport, RuntimeInfo, SettingsBundle } from '../shared/types'
import { analyze, listModels, resolveAi, testConnection } from './ai'
import { captureScreen, listDisplays } from './capture'
import { DashboardWindow } from './dashboard'
import { HotkeyService } from './hotkeys'
import { OverlayController, OVERLAY_HEIGHT, OVERLAY_WIDTH } from './overlay'
import { CaptureSession } from './session'
import * as store from './store'
import { createTray, type TrayHandle } from './tray'

const isDev = !app.isPackaged
const devServerUrl = process.env.ELECTRON_RENDERER_URL
const ASSET_HOST = 'asset'

app.setName('AI Bubble')

// Declared before ready so renderers can load capture artifacts by URL.
protocol.registerSchemesAsPrivileged([
  {
    scheme: ASSET_SCHEME,
    privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, bypassCSP: true }
  }
])

if (process.platform === 'win32') app.setAppUserModelId('com.aibubble.desktop')

// Containers and CI have no usable Chromium sandbox helper.
if (process.env.AIBUBBLE_NO_SANDBOX === '1' || process.env.AIBUBBLE_SMOKE === '1') {
  app.commandLine.appendSwitch('no-sandbox')
  app.commandLine.appendSwitch('disable-gpu')
}

let overlay: OverlayController
let dashboard: DashboardWindow
let hotkeys: HotkeyService
let capture: CaptureSession
let tray: TrayHandle = { available: false, refresh: () => undefined, destroy: () => undefined }
let learning = false
let quitting = false

function assetUrlFor(ref: string): string {
  return `${ASSET_SCHEME}://${ASSET_HOST}/${ref.split('/').map(encodeURIComponent).join('/')}`
}

function registerAssetProtocol(): void {
  protocol.handle(ASSET_SCHEME, (request) => {
    try {
      const url = new URL(request.url)
      const ref = decodeURIComponent(url.pathname.replace(/^\/+/, ''))
      const base = path.resolve(store.userDataDir())
      const target = path.resolve(base, ref)
      if (!target.startsWith(base + path.sep)) return new Response('forbidden', { status: 403 })
      if (!existsSync(target)) return new Response('not found', { status: 404 })
      const data = readFileSync(target)
      const type = target.endsWith('.jpg')
        ? 'image/jpeg'
        : target.endsWith('.png')
          ? 'image/png'
          : target.endsWith('.wav')
            ? 'audio/wav'
            : 'application/octet-stream'
      return new Response(new Uint8Array(data), {
        headers: { 'content-type': type, 'cache-control': 'no-store' }
      })
    } catch (error) {
      return new Response(String(error), { status: 500 })
    }
  })
}

/** Only macOS reports media permissions through systemPreferences; elsewhere it is absent. */
function mediaAccessStatus(kind: 'microphone' | 'screen' | 'camera'): string {
  const api = systemPreferences as { getMediaAccessStatus?: (value: string) => string }
  if (process.platform !== 'darwin' || typeof api.getMediaAccessStatus !== 'function') return 'n/a'
  try {
    return String(api.getMediaAccessStatus(kind))
  } catch {
    return 'n/a'
  }
}

/** The bubble only ever needs the microphone; camera and everything else is denied. */
function configurePermissions(): void {
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback, details) => {
    const mediaType = (details as { mediaType?: string }).mediaType
    // getUserMedia({audio}) for the recorder; video is never requested by this app.
    if (permission === 'media') return callback(mediaType !== 'video')
    return callback(permission === 'display-capture')
  })
  session.defaultSession.setPermissionCheckHandler((_webContents, permission) => {
    return permission === 'media' || permission === 'display-capture'
  })
}

async function buildRuntimeInfo(settings: AppSettings): Promise<RuntimeInfo> {
  const cfg = await resolveAi(settings)
  return {
    platform: process.platform,
    arch: process.arch,
    appVersion: app.getVersion(),
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    userData: store.userDataDir(),
    assetBase: `${ASSET_SCHEME}://${ASSET_HOST}/`,
    keySource: cfg.keySource,
    hasKey: Boolean(cfg.apiKey),
    secureStorage: store.secretStorageAvailable(),
    effectiveBaseUrl: cfg.baseUrl,
    effectiveModel: cfg.model,
    sessionType: process.env.XDG_SESSION_TYPE ?? 'desktop',
    trayAvailable: tray.available,
    hotkey: hotkeys.status(),
    displays: listDisplays().map(({ id, label, scaleFactor, isPrimary, isCursor }) => ({
      id,
      label,
      scaleFactor,
      isPrimary,
      isCursor
    }))
  }
}

async function buildHealth(settings: AppSettings): Promise<HealthReport> {
  const cfg = await resolveAi(settings)
  const listing = await listModels(cfg)
  const mic = capture.microphoneReport
  const displays = listDisplays()
  const status = hotkeys.status()

  let screenOk = false
  let screenDetail = ''
  try {
    const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 8, height: 8 } })
    screenOk = sources.length > 0
    screenDetail = `${sources.length} nguồn màn hình · ${displays.length} display`
  } catch (error) {
    screenDetail = error instanceof Error ? error.message : String(error)
  }

  const micPermission = mediaAccessStatus('microphone')
  const screenPermission = mediaAccessStatus('screen')

  return {
    checkedAt: Date.now(),
    platform: `${process.platform}/${process.arch}`,
    sessionType: process.env.XDG_SESSION_TYPE ?? 'desktop',
    key: {
      ok: Boolean(cfg.apiKey),
      source: cfg.keySource,
      detail: cfg.apiKey
        ? cfg.keySource === 'vault'
          ? 'Đã lưu trong kho mã hoá của hệ điều hành'
          : 'Đang dùng biến môi trường'
        : 'Chưa có key — mở Cài đặt → AI'
    },
    ai: {
      ok: listing.ok && listing.models.some((model) => model.id === cfg.model || model.vision),
      detail: listing.ok
        ? `${listing.models.length} model · đang dùng ${cfg.model}${
            cfg.strategy === 'multimodal' ? ' (audio + ảnh trong một lượt gọi)' : ` (STT: ${cfg.sttModel})`
          }`
        : `Lỗi: ${listing.error}`,
      models: listing.models.length
    },
    mic: {
      // An unmeasured microphone is a warning, not a green light: one session measures it.
      ok: mic ? mic.devices > 0 && mic.permission !== 'denied' : micPermission === 'granted',
      detail: mic
        ? `${mic.devices} thiết bị vào · quyền ${mic.permission}${mic.labels.length ? ` · ${mic.labels[0]}` : ''}`
        : micPermission === 'denied'
          ? 'Mic bị từ chối quyền'
          : 'Chưa đo: bấm phím nóng một lần để app tiếp cận mic',
      devices: mic?.devices ?? 0
    },
    screen: {
      ok: screenOk,
      detail: screenOk ? `${screenDetail} · quyền ${screenPermission}` : screenDetail,
      displays: displays.length
    },
    hotkey: { ok: status.ok, engine: status.engine, detail: status.detail }
  }
}

function wireIpc(): void {
  ipcMain.handle(API.getSnapshot, () => capture.snapshot())
  ipcMain.handle(API.toggle, (_event, origin: string) =>
    capture.toggle(origin === 'hotkey' ? 'hotkey' : 'dashboard', origin === 'hotkey' ? hotkeys.status().keyLabel : 'Dashboard')
  )
  ipcMain.handle(API.cancel, () => capture.cancel())
  ipcMain.handle(API.askText, (_event, text: string) => capture.askText(String(text ?? '')))

  ipcMain.handle(API.listHistory, () => store.listRecords())
  ipcMain.handle(API.deleteRecord, (_event, id: string) => store.removeRecord(String(id)))
  ipcMain.handle(API.clearHistory, () => store.clearRecords())
  ipcMain.handle(API.togglePin, async (_event, id: string, pinned: boolean) => {
    await store.setPinned(String(id), Boolean(pinned))
    return store.listRecords()
  })
  ipcMain.handle(API.exportHistory, async () => {
    const records = await store.listRecords()
    const { canceled, filePath } = await dialog.showSaveDialog({
      title: 'Xuất lịch sử AI Bubble',
      defaultPath: `ai-bubble-history-${new Date().toISOString().slice(0, 10)}.json`,
      filters: [{ name: 'JSON', extensions: ['json'] }]
    })
    if (canceled || !filePath) return { ok: false, path: '' }
    const { writeFile } = await import('node:fs/promises')
    await writeFile(filePath, JSON.stringify(records, null, 2), 'utf8')
    return { ok: true, path: filePath }
  })

  ipcMain.handle(API.getSettings, async (): Promise<SettingsBundle> => {
    const settings = await store.getSettings()
    return { settings, runtime: await buildRuntimeInfo(settings) }
  })

  ipcMain.handle(API.saveSettings, async (_event, patch: Partial<AppSettings>): Promise<SettingsBundle> => {
    const next = await store.saveSettings(patch)
    capture.applySettings(next)
    hotkeys.update(next.hotkey)
    overlay.setScale(next.overlay.scale)
    await applyLoginItem(next)
    tray.refresh()
    return { settings: next, runtime: await buildRuntimeInfo(next) }
  })

  ipcMain.handle(API.setApiKey, async (_event, key: string) => {
    const source = await store.setApiKey(String(key ?? ''))
    const settings = await store.getSettings()
    return { source, runtime: await buildRuntimeInfo(settings) }
  })

  ipcMain.handle(API.clearApiKey, async () => {
    const source = await store.setApiKey('')
    const settings = await store.getSettings()
    return { source, runtime: await buildRuntimeInfo(settings) }
  })

  ipcMain.handle(API.listModels, async () => listModels(await resolveAi(await store.getSettings())))
  ipcMain.handle(API.testConnection, async () => testConnection(await resolveAi(await store.getSettings())))
  ipcMain.handle(API.health, async () => buildHealth(await store.getSettings()))

  ipcMain.handle(API.learnKeyStart, () => {
    learning = true
    hotkeys.beginLearning()
    return { started: true, expires: Date.now() + 12000 }
  })

  ipcMain.handle(API.learnKeyStop, () => {
    learning = false
    hotkeys.endLearning()
    return true
  })

  ipcMain.handle(API.moveOverlay, (_event, position: { x?: number; y?: number } | 'reset') => {
    if (position === 'reset') {
      const { x, y, width, height } = screen.getPrimaryDisplay().workArea
      return overlay.moveTo({ x: x + width - OVERLAY_WIDTH - 20, y: y + height - OVERLAY_HEIGHT - 20 })
    }
    return overlay.moveTo({ x: Number(position?.x ?? 0), y: Number(position?.y ?? 0) })
  })

  ipcMain.handle(API.showOverlay, (_event, visible: boolean) => {
    if (visible) overlay.show()
    else overlay.hide()
    return overlay.isVisible()
  })

  ipcMain.handle(API.openDashboard, () => {
    dashboard.show()
    return true
  })

  ipcMain.handle(API.assetUrl, (_event, ref: string) => assetUrlFor(String(ref ?? '')))
  ipcMain.handle(API.openDataFolder, async () => {
    const message = await shell.openPath(store.userDataDir())
    return message || store.userDataDir()
  })
  ipcMain.handle(API.appInfo, async () => buildRuntimeInfo(await store.getSettings()))
}

function isFromOverlay(event: Electron.IpcMainEvent): boolean {
  return overlay.ready && event.sender.id === overlay.window!.webContents.id
}

function wireOverlayBridge(): void {
  ipcMain.on(OVERLAY_READY, (event) => {
    if (!isFromOverlay(event)) return
    overlay.send(OVERLAY_STATE, capture.snapshot())
  })

  ipcMain.on(OVERLAY_LEVEL, (event, level: number, elapsed: number) => {
    if (!isFromOverlay(event)) return
    capture.onLevel(Number(level), Number(elapsed))
  })

  ipcMain.on(OVERLAY_AUDIO, (event, payload: AudioPayload) => {
    if (!isFromOverlay(event)) return
    capture.onAudioResult(payload)
  })

  ipcMain.on(OVERLAY_RECORD_ERROR, (event, message: string) => {
    if (!isFromOverlay(event)) return
    capture.onRecordError(String(message))
  })

  ipcMain.on(OVERLAY_MIC, (event, report: MicReport) => {
    if (!isFromOverlay(event)) return
    capture.reportMic(report)
  })

  ipcMain.on(OVERLAY_ASK_TEXT, (event, text: string) => {
    if (!isFromOverlay(event)) return
    void capture.askText(String(text), 'bubble')
  })

  ipcMain.on(OVERLAY_INTERACTIVE, (event, hovering: boolean) => {
    if (!isFromOverlay(event)) return
    overlay.setHover(Boolean(hovering))
  })

  ipcMain.on(OVERLAY_DRAG, (event, delta: { dx: number; dy: number; done?: boolean }) => {
    if (!isFromOverlay(event)) return
    if (delta?.done) overlay.endDrag()
    else overlay.dragBy({ dx: Number(delta?.dx ?? 0), dy: Number(delta?.dy ?? 0) })
  })

  ipcMain.on(OVERLAY_REQUEST, (event, action: string) => {
    if (!isFromOverlay(event)) return
    switch (action) {
      case 'toggle':
        void capture.toggle('hotkey', hotkeys.status().keyLabel)
        break
      case 'collapse':
        overlay.allowKeyboardInput(false)
        overlay.setExpanded(false)
        void capture.cancel()
        break
      case 'focus-input':
        overlay.allowKeyboardInput(true)
        break
      case 'open-dashboard':
        dashboard.show()
        break
      default:
        break
    }
  })
}

function wireHotkeys(): void {
  hotkeys.on('toggle', async (label: string) => {
    if (learning) return
    await capture.toggle('hotkey', label)
    tray.refresh()
  })

  hotkeys.on('keycode', (keycode: number) => {
    if (!learning) return
    learning = false
    hotkeys.endLearning()
    dashboard.send(DASH_KEYCODE, { keycode, at: Date.now() })
  })

  // Never leave the observer in learning mode: that would echo every keystroke id.
  setInterval(() => {
    if (learning) {
      learning = false
      hotkeys.endLearning()
    }
  }, 15000).unref?.()
}

async function applyLoginItem(settings: AppSettings): Promise<void> {
  try {
    app.setLoginItemSettings({ openAtLogin: settings.general.launchAtLogin })
  } catch {
    /* not available on every platform build */
  }
}

function synthWav(seconds = 0.6, hz = 440): Uint8Array {
  const sampleRate = 16000
  const frames = Math.floor(sampleRate * seconds)
  const bytes = frames * 2
  const buffer = Buffer.alloc(44 + bytes)
  buffer.write('RIFF', 0)
  buffer.writeUInt32LE(36 + bytes, 4)
  buffer.write('WAVE', 8)
  buffer.write('fmt ', 12)
  buffer.writeUInt32LE(16, 16)
  buffer.writeUInt16LE(1, 20)
  buffer.writeUInt16LE(1, 22)
  buffer.writeUInt32LE(sampleRate, 24)
  buffer.writeUInt32LE(sampleRate * 2, 28)
  buffer.writeUInt16LE(2, 32)
  buffer.writeUInt16LE(16, 34)
  buffer.write('data', 36)
  buffer.writeUInt32LE(bytes, 40)
  for (let i = 0; i < frames; i += 1) {
    buffer.writeInt16LE(Math.round(3000 * Math.sin((2 * Math.PI * hz * i) / sampleRate)), 44 + i * 2)
  }
  return new Uint8Array(buffer)
}

/**
 * Headless verification used by `npm run smoke`: a real screen capture and a real AI
 * call from inside Electron. Prints one JSON line, then the caller exits the app.
 */
async function runSmoke(): Promise<number> {
  let ok = false
  const report: Record<string, unknown> = {
    platform: `${process.platform}/${process.arch}`,
    electron: process.versions.electron,
    displays: listDisplays().map((display) => display.label)
  }
  const settings = await store.getSettings()
  const cfg = await resolveAi(settings)
  Object.assign(report, { baseUrl: cfg.baseUrl, model: cfg.model, keySource: cfg.keySource, hotkey: hotkeys.status() })

  try {
    const shot = await captureScreen({ maxWidth: 1280, quality: 70, display: 'primary' })
    report.screenshot = { width: shot.width, height: shot.height, bytes: shot.bytes, label: shot.label }

    const started = Date.now()
    let streamedChars = 0
    const result = await analyze(
      cfg,
      {
        question: 'Ảnh này là màn hình của một app Electron. Trả lời đúng một câu: bạn thấy gì?',
        screenshotDataUrl: `data:image/jpeg;base64,${shot.jpeg.toString('base64')}`,
        audioWav: synthWav()
      },
      (full) => {
        streamedChars = full.length
      }
    )
    report.streamedChars = streamedChars
    report.answer = result.answer
    report.strategy = result.strategyUsed
    report.warnings = result.warnings
    report.aiMs = Date.now() - started

    const sttRun = await analyze({ ...cfg, strategy: 'transcribe_first' }, { question: '', audioWav: synthWav() })
    report.transcribe = { transcript: sttRun.transcript, answerChars: sttRun.answer.length, warnings: sttRun.warnings }
    report.health = await buildHealth(settings)

    ok = result.answer.length > 4
  } catch (error) {
    report.error = error instanceof Error ? `${error.name}: ${error.message}` : String(error)
  }

  report.ok = ok
  process.stdout.write(`\nSMOKE_JSON ${JSON.stringify(report, null, 1)}\n`)
  return ok ? 0 : 1
}

async function persistOverlayPosition(position: { x: number; y: number }): Promise<void> {
  const current = capture.currentSettings
  const next = await store.saveSettings({ overlay: { ...current.overlay, x: position.x, y: position.y } })
  capture.applySettings(next)
}

/**
 * `AIBUBBLE_SHOT=<dir>` renders the real interface and writes PNGs for visual review.
 * It drives the same session path a hotkey press uses, minus the microphone, so the
 * bubble card, the dashboard and the AI answer are all exercised together.
 */
async function runShotMode(): Promise<number> {
  const dir = process.env.AIBUBBLE_SHOT
  if (!dir || !dashboard || !overlay) return 1
  mkdirSync(dir, { recursive: true })

  const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms))
  const shot = async (name: string, win: BrowserWindow | null): Promise<void> => {
    if (!win || win.isDestroyed()) return
    const image = await win.webContents.capturePage()
    writeFileSync(path.join(dir, `${name}.png`), image.toPNG())
  }
  const clickTab = async (index: number): Promise<void> => {
    await dashboard!.window?.webContents.executeJavaScript(
      `document.querySelectorAll('.nav-item')[${index}]?.click(); true`
    )
    await sleep(700)
  }

  await sleep(3200)
  await shot('01-dashboard-overview', dashboard.window)
  await clickTab(2)
  await shot('02-dashboard-settings', dashboard.window)
  await clickTab(1)
  await shot('03-dashboard-history', dashboard.window)
  await clickTab(0)

  await capture.askText('Mô tả ngắn những gì bạn thấy trên màn hình này.', 'dashboard')
  for (let i = 0; i < 90; i += 1) {
    const phase = capture.snapshot().phase
    if (phase === 'answer' || phase === 'error') break
    await sleep(500)
  }
  await sleep(1200)
  await shot('04-overlay-answer', overlay.window)
  await sleep(500)
  await shot('05-dashboard-with-session', dashboard.window)

  process.stdout.write(`[ai-bubble] shots written to ${dir} · phase=${capture.snapshot().phase}\n`)
  return 0
}

async function bootstrap(): Promise<void> {
  const userData = await store.initStore()
  await store.probeSecretStorage()
  const settings = await store.getSettings()
  await applyLoginItem(settings)
  registerAssetProtocol()
  configurePermissions()

  const preload = path.join(__dirname, '../preload/index.js')
  overlay = new OverlayController({
    preload,
    isDev,
    devServerUrl,
    onPositionChange: (position) => void persistOverlayPosition(position)
  })
  dashboard = new DashboardWindow({
    preload,
    isDev,
    devServerUrl,
    shouldHideOnClose: () => !quitting
  })
  hotkeys = new HotkeyService()
  capture = new CaptureSession({ overlay, dashboard, hotkeys })
  await capture.loadSettings()

  const restored =
    settings.overlay.x !== null && settings.overlay.y !== null ? { x: settings.overlay.x, y: settings.overlay.y } : null
  overlay.create(restored)
  overlay.show()
  overlay.setScale(settings.overlay.scale)

  wireIpc()
  wireOverlayBridge()
  wireHotkeys()
  await hotkeys.start(settings.hotkey)

  tray = createTray({
    iconPath: path.join(app.getAppPath(), 'build', 'tray.png'),
    getState: () => capture.snapshot(),
    onToggle: () => void capture.toggle('hotkey', hotkeys.status().keyLabel),
    onDashboard: () => dashboard.show(),
    onToggleBubble: () => (overlay.isVisible() ? overlay.hide() : overlay.show())
  })

  screen.on('display-metrics-changed', () => {
    const bounds = overlay.currentBounds()
    overlay.moveTo({ x: bounds.x, y: bounds.y })
  })

  if (!settings.general.startHidden) dashboard.show()

  process.stdout.write(`[ai-bubble] ready · userData=${userData} · tray=${tray.available} · hotkey=${JSON.stringify(hotkeys.status())}\n`)

  if (process.env.AIBUBBLE_SMOKE === '1') {
    const code = await runSmoke()
    app.exit(code)
  }
  if (process.env.AIBUBBLE_SHOT) {
    const code = await runShotMode()
    app.exit(code)
  }
}

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => dashboard?.show())

  app.whenReady().then(bootstrap).catch((error) => {
    process.stderr.write(`[ai-bubble] bootstrap failed: ${error instanceof Error ? error.stack ?? error.message : String(error)}\n`)
    app.exit(1)
  })

  app.on('before-quit', () => {
    quitting = true
    hotkeys?.stop()
    tray?.destroy()
  })

  // Closing the dashboard must not quit: the bubble is the product.
  app.on('window-all-closed', () => undefined)

  app.on('activate', () => dashboard?.show())
}
